<?php 

session_start();
$_SESSION['total'] = $_POST['total'];

?>