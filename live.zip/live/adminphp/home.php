<?php
	require 'templates/top.inc.php';
?>

<?php
	require 'templates/bottom.inc.php';
?>