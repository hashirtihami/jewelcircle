<?php
header( "location: homephp/index" );
?>